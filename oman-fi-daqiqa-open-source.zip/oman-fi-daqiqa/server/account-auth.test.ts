import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./_core/accountAuth";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

describe("account authentication", () => {
  it("stores passwords as salted hashes and verifies them", async () => {
    const password = "SafePassword123!";
    const hash = await hashPassword(password);
    expect(hash).not.toContain(password);
    expect(await verifyPassword(password, hash)).toBe(true);
    expect(await verifyPassword("wrong-password", hash)).toBe(false);
  });

  it("blocks disabled accounts from protected procedures", async () => {
    const ctx: TrpcContext = {
      user: {
        id: 8,
        openId: null,
        name: "Disabled Student",
        englishName: null,
        email: "disabled@example.com",
        passwordHash: null,
        loginMethod: "email",
        role: "user",
        accountRole: "student",
        accountStatus: "disabled",
        gender: "male",
        grade: null,
        className: null,
        permissions: null,
        emailVerifiedAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.profile.me()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("blocks students from member management", async () => {
    const ctx: TrpcContext = {
      user: {
        id: 9, openId: null, name: "Student", englishName: null, email: "student@example.com", passwordHash: null,
        loginMethod: "email", role: "user", accountRole: "student", accountStatus: "active", gender: "male",
        grade: "5/1", className: null, permissions: null, emailVerifiedAt: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date(),
      },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.members.list()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
