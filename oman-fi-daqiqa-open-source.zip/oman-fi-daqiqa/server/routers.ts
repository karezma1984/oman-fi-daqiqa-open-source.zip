import { ACCOUNT_COOKIE_NAME, COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createInvitation, createParagraph, getDb, getParagraphById, getUserById, listMembers, listParagraphs, updateMember, updateParagraph, writeAuditLog } from "./db";
import { passwordResetTokens, users } from "../drizzle/schema";
import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createAccountSession, hashPassword, hashResetToken, verifyPassword } from "./_core/accountAuth";
import { eq } from "drizzle-orm";
import { storagePut } from "./storage";

const memberRole = z.enum(["teacher", "student", "team"]);
const accountStatus = z.enum(["pending", "active", "disabled"]);
const permissionList = z.array(z.string()).max(40);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    register: publicProcedure.input(z.object({
      name: z.string().min(2).max(120),
      englishName: z.string().max(120).optional(),
      email: z.string().email(),
      password: z.string().min(8).max(128),
      gender: z.enum(["male", "female"]).optional(),
      grade: z.string().max(32).optional(),
      className: z.string().max(32).optional(),
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, input.email)).limit(1);
      if (existing.length) throw new TRPCError({ code: "CONFLICT", message: "An account with this email already exists." });
      const result = await db.insert(users).values({ name: input.name, englishName: input.englishName, email: input.email, passwordHash: await hashPassword(input.password), gender: input.gender, grade: input.grade, className: input.className, loginMethod: "email", accountRole: "student", accountStatus: "pending", role: "user" });
      const userId = Number(result[0].insertId);
      const token = await createAccountSession(userId);
      ctx.res.cookie(ACCOUNT_COOKIE_NAME, token, { httpOnly: true, secure: true, sameSite: "none", path: "/", maxAge: 7 * 24 * 60 * 60 * 1000 });
      return { success: true, status: "pending" as const };
    }),
    login: publicProcedure.input(z.object({ email: z.string().email(), password: z.string().min(1) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const result = await db.select().from(users).where(eq(users.email, input.email)).limit(1);
      const account = result[0];
      if (!account?.passwordHash || !(await verifyPassword(input.password, account.passwordHash))) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email or password." });
      if (account.accountStatus === "disabled") throw new TRPCError({ code: "FORBIDDEN", message: "This account is disabled." });
      await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, account.id));
      const token = await createAccountSession(account.id);
      ctx.res.cookie(ACCOUNT_COOKIE_NAME, token, { httpOnly: true, secure: true, sameSite: "none", path: "/", maxAge: 7 * 24 * 60 * 60 * 1000 });
      return { success: true, status: account.accountStatus };
    }),
    requestPasswordReset: publicProcedure.input(z.object({ email: z.string().email() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) return { success: true } as const;
      const result = await db.select({ id: users.id }).from(users).where(eq(users.email, input.email)).limit(1);
      if (result[0]) {
        const rawToken = randomBytes(32).toString("hex");
        await db.insert(passwordResetTokens).values({ userId: result[0].id, tokenHash: hashResetToken(rawToken), expiresAt: new Date(Date.now() + 60 * 60 * 1000) });
        // Delivery is intentionally decoupled from token creation; connect an email provider to send rawToken.
      }
      return { success: true } as const;
    }),
    resetPassword: publicProcedure.input(z.object({ token: z.string().min(32), password: z.string().min(8).max(128) })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const result = await db.select().from(passwordResetTokens).where(eq(passwordResetTokens.tokenHash, hashResetToken(input.token))).limit(1);
      const reset = result[0];
      if (!reset || reset.usedAt || reset.expiresAt.getTime() < Date.now()) throw new TRPCError({ code: "BAD_REQUEST", message: "The reset link is invalid or expired." });
      await db.update(users).set({ passwordHash: await hashPassword(input.password), updatedAt: new Date() }).where(eq(users.id, reset.userId));
      await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, reset.id));
      return { success: true } as const;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie(ACCOUNT_COOKIE_NAME, { secure: true, sameSite: "none", httpOnly: true, path: "/", maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  paragraphs: router({
    list: protectedProcedure.query(({ ctx }) => listParagraphs(ctx.user.accountRole === "admin" || ctx.user.accountRole === "teacher" ? undefined : ctx.user.id)),
    get: protectedProcedure.input(z.object({ paragraphId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const paragraph = await getParagraphById(input.paragraphId);
      if (!paragraph || (paragraph.createdBy !== ctx.user.id && ctx.user.accountRole !== "admin" && ctx.user.accountRole !== "teacher")) throw new TRPCError({ code: "NOT_FOUND", message: "Paragraph not found" });
      return paragraph;
    }),
    create: protectedProcedure.input(z.object({
      title: z.string().min(1).max(255), topic: z.string().min(1).max(120), content: z.string().min(1),
      audioUrl: z.string().max(2000).optional(), videoUrl: z.string().max(2000).optional(), pdfUrl: z.string().max(2000).optional(), imageUrl: z.string().max(2000).optional(),
      status: z.enum(["draft", "pending_review"]).default("draft"), studentName: z.string().min(1).max(255).optional(),
    })).mutation(async ({ ctx, input }) => {
      const saved = await createParagraph({ ...input, studentName: input.studentName || ctx.user.name || ctx.user.englishName || "Student", createdBy: ctx.user.id });
      await writeAuditLog(ctx.user.id, "paragraph.create", undefined, { paragraphId: saved.paragraphId });
      return saved;
    }),
    update: protectedProcedure.input(z.object({ paragraphId: z.number().int().positive(), title: z.string().min(1).max(255).optional(), topic: z.string().min(1).max(120).optional(), content: z.string().min(1).optional(), audioUrl: z.string().max(2000).nullable().optional(), videoUrl: z.string().max(2000).nullable().optional(), pdfUrl: z.string().max(2000).nullable().optional(), imageUrl: z.string().max(2000).nullable().optional(), status: z.enum(["draft", "pending_review", "approved", "published", "archived"]).optional() })).mutation(async ({ ctx, input }) => {
      const existing = await getParagraphById(input.paragraphId);
      if (!existing || (existing.createdBy !== ctx.user.id && ctx.user.accountRole !== "admin" && ctx.user.accountRole !== "teacher")) throw new TRPCError({ code: "FORBIDDEN", message: "You cannot edit this paragraph" });
      const { paragraphId, ...patch } = input;
      const saved = await updateParagraph(paragraphId, patch);
      await writeAuditLog(ctx.user.id, "paragraph.update", paragraphId, { fields: Object.keys(patch) });
      return saved;
    }),
    archive: protectedProcedure.input(z.object({ paragraphId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const existing = await getParagraphById(input.paragraphId);
      if (!existing || (existing.createdBy !== ctx.user.id && ctx.user.accountRole !== "admin" && ctx.user.accountRole !== "teacher")) throw new TRPCError({ code: "FORBIDDEN", message: "You cannot archive this paragraph" });
      const saved = await updateParagraph(input.paragraphId, { status: "archived" });
      await writeAuditLog(ctx.user.id, "paragraph.archive", input.paragraphId);
      return saved;
    }),
  }),
  media: router({
    upload: protectedProcedure.input(z.object({
      filename: z.string().min(1).max(180),
      contentType: z.string().min(1).max(120),
      data: z.string().min(1).max(35_000_000),
    })).mutation(async ({ ctx, input }) => {
      const bytes = Buffer.from(input.data, "base64");
      if (!bytes.length || bytes.length > 25 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "Attachment must be between 1 byte and 25 MB." });
      const safeFilename = input.filename.replace(/[^a-zA-Z0-9._-]/g, "-");
      return storagePut(`paragraph-media/${ctx.user.id}/${Date.now()}-${safeFilename}`, bytes, input.contentType);
    }),
  }),
  profile: router({
    me: protectedProcedure.query(({ ctx }) => ctx.user),
    update: protectedProcedure.input(z.object({
      name: z.string().min(2).max(120).optional(),
      englishName: z.string().max(120).optional(),
      gender: z.enum(["male", "female"]).optional(),
      grade: z.string().max(32).optional(),
      className: z.string().max(32).optional(),
    })).mutation(async ({ ctx, input }) => {
      const updated = await updateMember(ctx.user.id, input);
      await writeAuditLog(ctx.user.id, "profile.update", ctx.user.id, { fields: Object.keys(input) });
      return updated;
    }),
  }),
  members: router({
    list: adminProcedure.input(z.object({ search: z.string().optional(), role: z.enum(["admin", "teacher", "student", "team"]).optional() }).optional()).query(({ input }) => listMembers(input?.search, input?.role)),
    create: adminProcedure.input(z.object({
      name: z.string().min(2),
      englishName: z.string().optional(),
      email: z.string().email(),
      accountRole: memberRole,
      gender: z.enum(["male", "female"]).optional(),
      grade: z.string().optional(),
      className: z.string().optional(),
      permissions: permissionList.default([]),
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      const result = await db.insert(users).values({
        email: input.email,
        name: input.name,
        englishName: input.englishName,
        accountRole: input.accountRole,
        accountStatus: "active",
        gender: input.gender,
        grade: input.grade,
        className: input.className,
        permissions: JSON.stringify(input.permissions),
        loginMethod: "admin-created",
      });
      const id = Number(result[0].insertId);
      await writeAuditLog(ctx.user.id, "member.create", id, { email: input.email, role: input.accountRole });
      return getUserById(id);
    }),
    update: adminProcedure.input(z.object({
      id: z.number().int().positive(),
      name: z.string().min(2).optional(),
      englishName: z.string().optional(),
      accountRole: z.enum(["admin", "teacher", "student", "team"]).optional(),
      accountStatus,
      permissions: permissionList.optional(),
      gender: z.enum(["male", "female"]).optional(),
      grade: z.string().optional(),
      className: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      const { id, permissions, ...patch } = input;
      const updated = await updateMember(id, { ...patch, permissions: permissions ? JSON.stringify(permissions) : undefined });
      await writeAuditLog(ctx.user.id, "member.update", id, { fields: Object.keys(input) });
      return updated;
    }),
    invite: adminProcedure.input(z.object({ email: z.string().email(), invitedRole: memberRole, permissions: permissionList.default([]) })).mutation(async ({ ctx, input }) => {
      const rawToken = randomBytes(32).toString("hex");
      const tokenHash = createHash("sha256").update(rawToken).digest("hex");
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      const invitation = await createInvitation({ email: input.email, invitedRole: input.invitedRole, permissions: JSON.stringify(input.permissions), tokenHash, invitedBy: ctx.user.id, expiresAt });
      await writeAuditLog(ctx.user.id, "member.invite", undefined, { email: input.email, role: input.invitedRole });
      return { ...invitation, inviteToken: rawToken };
    }),
  }),
});

export type AppRouter = typeof appRouter;
