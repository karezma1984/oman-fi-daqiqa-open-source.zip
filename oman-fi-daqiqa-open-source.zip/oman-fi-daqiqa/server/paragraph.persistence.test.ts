import { describe, expect, it } from "vitest";
import { createParagraph, getParagraphById, listParagraphs, updateParagraph } from "./db";

describe("paragraph persistence lifecycle", () => {
  it("persists all fields across create, retrieve, edit, refresh, and archive", async () => {
    if (!process.env.DATABASE_URL) return;
    const marker = `Persistence test ${Date.now()}`;
    const created = await createParagraph({
      title: marker,
      studentName: "Mohammed Al Araimi",
      topic: "Historic landmark",
      content: "Nizwa Fort test content",
      audioUrl: "/manus-storage/test-audio.mp3",
      videoUrl: "/manus-storage/test-video.mp4",
      pdfUrl: "/manus-storage/test.pdf",
      imageUrl: "/manus-storage/test.png",
      status: "draft",
      createdBy: 1,
    });

    expect(created.paragraphId).toBeGreaterThan(0);
    expect((await getParagraphById(created.paragraphId))?.content).toBe("Nizwa Fort test content");
    expect((await listParagraphs(1)).some(item => item.paragraphId === created.paragraphId)).toBe(true);

    const edited = await updateParagraph(created.paragraphId, {
      title: `${marker} edited`,
      content: "Edited content after reopening the app",
      status: "pending_review",
    });
    expect(edited.title).toContain("edited");
    expect(edited.audioUrl).toBe("/manus-storage/test-audio.mp3");
    expect(edited.videoUrl).toBe("/manus-storage/test-video.mp4");
    expect(edited.pdfUrl).toBe("/manus-storage/test.pdf");
    expect(edited.imageUrl).toBe("/manus-storage/test.png");

    const afterRefresh = await getParagraphById(created.paragraphId);
    expect(afterRefresh?.content).toBe("Edited content after reopening the app");
    expect(afterRefresh?.status).toBe("pending_review");

    const archived = await updateParagraph(created.paragraphId, { status: "archived" });
    expect(archived.status).toBe("archived");
  });
});
