import { describe, expect, it } from "vitest";
import { canTransition, contentWorkflow, mediaKinds, platformRoles } from "../shared/platform";

describe("oman fi daqiqa platform rules", () => {
  it("keeps the content lifecycle ordered from draft to publish", () => {
    expect(contentWorkflow.map((item) => item.key)).toEqual(["draft", "teacher_review", "approved", "published"]);
    expect(canTransition("draft", "teacher_review")).toBe(true);
    expect(canTransition("draft", "published")).toBe(false);
    expect(canTransition("published", "draft")).toBe(false);
  });

  it("defines the school roles and protected media kinds", () => {
    expect(platformRoles.map((role) => role.key)).toEqual(["supervisor", "teacher", "student"]);
    expect(mediaKinds).toEqual(["audio", "video", "pdf", "image"]);
  });
});
