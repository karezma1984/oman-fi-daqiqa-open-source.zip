import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { ACCOUNT_COOKIE_NAME } from "@shared/const";
import { parse } from "cookie";
import { getUserById } from "../db";
import { readAccountSession } from "./accountAuth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  if (!user) {
    const token = parse(opts.req.headers.cookie || "")[ACCOUNT_COOKIE_NAME];
    if (token) {
      const userId = await readAccountSession(token);
      if (userId) user = (await getUserById(userId)) ?? null;
    }
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
