# عُمان في دقيقة — Oman in a Minute

A bilingual Arabic/English school radio platform for creating, reviewing, publishing, and printing short Omani heritage assignments.

## Highlights

- Arabic RTL and English LTR interfaces
- Durable paragraph storage with database-backed create, edit, archive, and retrieval flows
- Student and supervisor account workflows
- Audio, image, PDF, and video attachments
- Offline audio and transcript downloads
- Governorate → wilayah → landmark selection with ready-made 60-second radio scripts
- Arabic A4 print preview and printing for selected assignments
- Copy and share actions for presenters
- Vitest coverage for authentication, permissions, and paragraph persistence

## Tech stack

- React 19 + Vite
- TypeScript
- Tailwind CSS and shadcn/ui components
- Express + tRPC
- Drizzle ORM with MySQL/TiDB
- Manus OAuth and storage integrations

## Development

```bash
pnpm install
pnpm dev
```

Run validation:

```bash
pnpm check
pnpm build
pnpm test
```

## Environment

The hosted Manus project supplies the required runtime environment variables for authentication, database access, storage, and built-in services. For local development, configure the variables documented by the deployment environment; never commit `.env` files or secrets.

## Project structure

- `client/` — React interface and pages
- `server/` — tRPC procedures, authentication, database helpers, and storage
- `drizzle/` — database schema and migrations
- `shared/` — shared constants and types

## License

MIT. See [LICENSE](./LICENSE).
