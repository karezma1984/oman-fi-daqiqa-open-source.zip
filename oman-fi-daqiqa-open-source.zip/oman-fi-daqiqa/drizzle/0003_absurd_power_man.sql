CREATE TABLE `paragraphs` (
	`paragraph_id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`student_name` varchar(255) NOT NULL,
	`topic` varchar(120) NOT NULL,
	`content` text NOT NULL,
	`audio_url` text,
	`video_url` text,
	`pdf_url` text,
	`image_url` text,
	`status` enum('draft','pending_review','approved','published','archived') NOT NULL DEFAULT 'draft',
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `paragraphs_paragraph_id` PRIMARY KEY(`paragraph_id`)
);
